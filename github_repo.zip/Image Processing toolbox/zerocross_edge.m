function [ output_image ] = zerocross_edge( input_image )
output_image=edge(input_image,'zerocross');

end
