function [ output_image ] = LOG_edge( input_image )
output_image=edge(input_image,'log');

end
